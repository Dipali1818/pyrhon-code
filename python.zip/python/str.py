str1=str(input("enter string "))
print(str1.lower())  #uppercase conversion
           #lowercase conversion
print(str1.upper())
