#dipali gavade
#pallindrome

def pallindrome(string):
    if(string==string[::-1]):
        return True
    else:
        return False
print(pallindrome("aba"))
