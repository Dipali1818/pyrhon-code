#set function
s1={6,7,8,9,10}
print("set created",s1)

#update
s1={1,2,3,4,5}
s2={"p","q","r"}
s1.update(s2)
print("update is",s2.update is s1)

#add
s3={1,2,3,4,5}
s3.add(10)
print("add is",s3)

#remove
s3={1,2,3,4,5,14,3}
s3.remove(5)
print("remove is",s3)

#discard
s3={1,2,3,4,5}
s3.discard(5)
print("discard is",s3)

#pop
s3={1,2,3,4,5}
print("pop is",s3.pop())

#clear
s3={1,2,3,4,5}
s3.clear()
print("clear is",s3)

#intersection
s4={2,3,4,5}
s2={1,2,3}
print("intersection is",s4.intersection(s2))

#diff
s3={1,2,3,4,5,3,2,1}
s1={1,2,4,7,8,9,7}
print("difference is",s3.difference(s1))

#symmetric_difference
s3={1,2,3,4,5,9,2}
s1={1,2,4,7,8,4,2,3,5}
print("symmetric difference is",s3.symmetric_difference(s1))

#copy
s3={1,2,3,4,5}
print("copy is",s3.copy())

#min
s3={1,8,3,4,5}
print("min is",min(s3))

#max
s3={10,20,30,40,50}
print("max is",max(s3))

#sorted
s3={50,30,22,61,12}
print("sort is",sorted(s3))
