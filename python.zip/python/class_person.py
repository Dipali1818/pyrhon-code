class Person:
    def _init_(self,name,age,gender):
        self.name=name
        self.age=age
        self.gender=gender

class Faculty(Person):
    def _init_(self,name,age,gender,designation,department):
        super()._init_(name,age,gender)
        self.designation=designation
        self.department=department

class Publications:
    def _init_(self,num_research,num_books,num_articles):
        self.num_research=num_research
        self.num_books=num_books
        self.num_articles=num_articles

faculty=Faculty("Professor John",54,"Male","Professor","computer science")

publications=Publications(10,2,15)

faculty_publications=publications

print(f"Faculty name: {faculty.name}")
print(f"Faculty age: {faculty.age}")
print(f"faculty gender: {faculty.gender}")
print(f"faculty designation: {faculty.designation}")
print(f"faculty department: {faculty.department}")
#print(Faculty Publications:{faculty_publications.num})
