import math
num=4
abs_num=abs(num)
factorial_num=math.factorial(num);
array=[1,2,3,4];
sum_array=sum(array)
print("absolute value is",abs_num);
print("factorial no is",factorial_num)
print("sum of array is",sum_array)

