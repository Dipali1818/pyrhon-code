class complex():
    def__init__(self,a,b):
        self.real=a;
        self.img=b;
    def add(self,obj):
        temp=complex()
        temp.real=self.real+obj.real
        temp.img=self.img+obj.img;
        return temp
obj1=complex(2,3)
obj2=complex(3,5)
obj3=obj1+obj2
print("sum of complex is",obj3.img "+"obj3.real)
