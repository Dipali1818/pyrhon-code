
try:
    a=int(input("enter the value"))
    b=int(input("enter the value"))
    for i in range(a,b+1):
        if(i>10):
            raise StopIteration
            print(i)
except StopIteration:
    print("in exception")
