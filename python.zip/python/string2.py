s="dipali"
print(len(s))  #lengh of file
print("count is")
print(s.count("d")) #count the character
print("startswith is")
print(s.startswith("d"))#startswith
#endswith
print("endswith is")
print(s.endswith("i"))
#center
print("center is")
print(s.center(6, "*"))
print("find is")
print(s.find("l"))  #find
#index
print("index is")
print(s.index("d"))  #ccheck index
#check alphanumeric
print("alnum is")
print(s.isalnum())
#check alpahbet
#print(s.isal())
a="345"  #check digit
print("digit is")
print(a.isdigit())
#check space
b=" "
print("space is")
print(b.isspace())
print(s + a)
#print(s notin a)
#uppercase
print("upper is")
print(s.upper())
#check lowercase
print("lowercase is")
print(s.lower())
#just is
print("just is")
print(s.ljust(6,"*"))
print("rjust is")
print(s.rjust(6,"*"))

s1="gavade dipali"     #title
print("title is")
print(s1.title())
#cpitalize
print("capitalize is")
print(s1.capitalize())
#swapcase
print("swapcase is")
print(s1.swapcase())
print(max(s1))  #max element
#min element 
print(min(s1))

str1="aarya"
#replace ele
print("replaces is")
print(str1.replace("r","b"))
print(s1.split(",")) #" " to ' ' #split
print("rstrip is")
print(str1.rstrip()) #strip to right
print("lstrip is")
print(str1.lstrip()) #lstrip

print("identity")
print(id(str1) is id(s1))  #identity
print(id(str1) is not id(s1))
print(str1.isidentifier())

print("strip is")
print(str1.strip()) #strip
#print(str1.isin("r"))


b="22"
#numeric 
print("is numeric ")
print(a.isnumeric())
print("decimal is")
print(b.isdecimal())
print("in is"'a' in str1)
#print(multiply(a,b))

s="abv"
print("zfill is",s.zfill(5)) #zfill





    
