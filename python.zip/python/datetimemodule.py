import datetime
current_datetime=datetime.datetime.now()
current_year=current_datetime.year
current_month=current_datetime.month
current_day=current_datetime.day
print("current datetime is",current_datetime)
print("current year is",current_year)
print("current month is ",current_month)
print("current day is",current_day);
