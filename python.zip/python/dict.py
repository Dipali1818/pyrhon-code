
Dict = {1,"eks", 3, 'eks'}
print(Dict)
 
Dict = {}
print("Empty Dictionary: ")  #empty dict
print(Dict)

      #nested
Dict = {1: 'abc', 2: 'For',
3: {'A': 'Welcome', 'B': 'To', 'C': 'eks'}}
 
print(Dict)

Dict[0] = 'eks'
Dict[2] = 'For'
Dict[3] = 1
print("\nDictionary after adding 3 elements: ")
print(Dict)
 
Dict['Value_set'] = 2, 3, 4
print("\nDictionary after adding 3 elements: ")
print(Dict)
 
Dict[2] = 'Welcome'    #dictionary value updated
print("\nUpdated key value: ")
print(Dict)
Dict[5] = {'Nested': {'1': 'Life', '2': 'eks'}}
print("\nAdding a Nested Key: ")
print(Dict)

#access value

Dict = {1: 'eks', 'name': 'For', 3: 'eks'}
print("Accessing a element using key:")
print(Dict['name'])
print("Accessing a element using key:")
print(Dict[1])

Dict = {1: 'eks', 'name': 'For', 3: 'eks'}
 
print("Accessing a element using get:")
print(Dict.get(3))

Dict = {'Dict1': {1: 'ks'},
        'Dict2': {'Name': 'For'}}
 
print(Dict['Dict1'])
print(Dict['Dict1'][1])
print(Dict['Dict2']['Name'])

#del(Dict[1]) #delete


dict2 = dict1.copy()
print(dict2)
dict1.clear()
print(dict1)
print(dict2.get(1))
print(dict2.items())
print(dict2.keys())
dict2.pop(4)
print(dict2)
dict2.popitem()
print(dict2)

