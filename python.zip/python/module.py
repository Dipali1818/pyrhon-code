#module
def add(x,y):
    return(x+y)

import calc
sum=calc.add(x,y)
print(cal.add)
