t1=(1,2,(5,6,7),3,4)
print(type(t1))
print(t1)
print(t1[2])
print(t1[2][2])
print(len(t1))

#t2=('a','b')
#del t2
#print(t2)

t3=('a','z','o')
print(type(t3))

t4=(9,)
print(t4)

t5=t1+t4
print(t5)

print(t5*2)       #repetation
print(t5.count(1)) #count the element

print(t5.index(2)) #index of elemen

print(max(t3))
print("max")              #maximum
print("minimum is",min(t3)) #minimum


print(t3 in t4)

t4=t3
print(t4) #touple assignment

#update
(var1,var2)=("a","b")
print(var1) #unname

t6=()
print(t6)


