#average of positive and negative number
pcount=0;
ncount=0;
pave=0;
nave=0;
for i in range(0,4):
    no=int(input("enter the value"))
    if(no==-1):
       break;
    elif(no>0):
        pcount=pcount+1;
        pave=pave+no;
    else:
        ncount=ncount+1;
        nave=nave+no;
paverage=pave/pcount
naverage=nave/ncount
print("positive average is",paverage)
print("negative average is",naverage)
    
