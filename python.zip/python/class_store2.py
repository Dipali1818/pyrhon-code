class Product:
    def _init_(self,code,name,price):
        self.code=code
        self.name=name
        self.price=price
class Store:
    def _init_(self):
        self.products=[]
    def add_product(self,product):
        self.products.append(product)
    def display_menu(self):
        print("Product Menu")
        for product in self.products:
            print(f"Code: {product.code},Name: {product.name},Price: {product.price}")
    def generate_bill(self):
        total_cost=0
        print("Bill")
        for product in self.products:
            quantity=int(input(f"Enter quantity of {product.name}: "))
            subtotal=product.price*quantity
            total_cost += subtotal
            print(f"{product.name} x {quantity}={subtotal}")
            print(f"Total cost :Rs.{total_cost}")

store=Store()

apple=Product("ap10","apple",20)
orange=Product("or20","orange",30)
mango=Product("ma30","mango",40)

store.add_product(apple)
store.add_product(orange)
store.add_product(mango)

store.display_menu()

store.generate_bill()
