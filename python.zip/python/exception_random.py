import random
class randomerror(Exception):
    pass
try:
    num=random.random()
    if(num<0.1):
        raise RandomError
except RandomError:
    print("random error")
else:
    print(num)
