#int value
a=11
print("type of a is",type(a))

#float value
b=1.1
print("type of bis",type(b))

#string
c="abc"
print(type(c))

#Complex
d=1+5j
print(type(d))

#boolean
var2=True
print(type(var2))
