#arithmatic operations in python

a=80
b=10
c=a+b
print("add is ",c)
print("sub is ",a-b)
print("multiplication is ",a*b)
print("division is",a/b)
print("mod is",a%b)

#comparison operator
#equal to
str="abc"
str2="xyz"
if(str==str2):
    print("equal")
else:
    print("not equal")

m=13
n=66
print("greater than",m>n)
print("less than",(m<n))
print("equal to",m==n)
print("not equal to",m!=n)
print("greater equal to",m>=n)
print("less than equal to",m<=n)

#logical operator


j=True
k=False
print("and is",j and k)
print("or is",j or k)
print("not is",not j)


#bitwise
o=10
h=4
print("& is",o & h)
print("|is",o | h)
print("<< is",o<<2)
print(">> is",h>>4)

r=5;
y=r;
print("ass is",r);
y+=r
print("addition assignment is",y)
y-=r
print("substraction assignment is",y)
y*=r
print("mul assignment is",y)
y/=r
print("div assignment is",y)


#idetity operator
print("identity is",a is b)
print("identity operator is",a is not b)

#memership operator
b=4
list=[1,2,3,4]
print("membership operator is",b in list)
print("membership operator is",b  not in list)




