#dipali SOmnath Gavade
#two lists are equal or not

def fun(list1,list2):
    if(list1==list2):
        return True
    else:
        return False
print(fun([1,2,4,5],[1,2,4,5]))
