#annual interest
totalinvestment=0
annualinterest=int(input("enter the value of annualintersest"))
investment=int(input("enter the value of investment"))
year=int(input("enter the value of time"))
for i in range(1,year+1):
    totalinvestment=annualinterest-totalinvestment;
    print(totalinvestment)
