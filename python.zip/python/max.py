#largest no among 3
a=int(input(" a enter the value"))
b=int(input(" b enter the value"))
c=int(input(" c enter the value"))
if(a>b and a>c):
    print("a is greater")
elif(b>a and b>c):
    print("b is greater")
else:
    print("c is greater")
