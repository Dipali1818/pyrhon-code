class complex():
    def __init__(self,a,b):
        self.real=a;
        self.img=b;
    def add(self,obj):
        temp=complex(0,0)
        temp.real=self.real+obj.real
        temp.img=self.img+obj.img;
        return temp
obj1=complex(2,3)
obj2=complex(3,5)
obj3=obj1+obj2
print(obj3.real,obj3.img)
