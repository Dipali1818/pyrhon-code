#factorial
n=int(input("enter no"))
def fact(n):
    for i in range(1,n,-1):
        if(n==1 or n==0):
            return 1
        elif(n>1):
            return fact*fact(n-1)
        else:
            return 0
result=fact(n)
print(result)
