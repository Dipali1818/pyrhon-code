
file=open("abc.txt","w")
file.write("welcome to python")
file=open("abc.txt","r")
#file.write("welcome to python")
print(file.read())
file.close()
