#display the no
no=int(input("enter the no"))
if(no==1):
    print("day is sunday")
elif(no==2):
    print("day is monday")
elif(no==3):
    print("day is tuesday")
elif(no==4):
    print("day is wednesday")
elif(no==5):
    print("day is thursday")
elif(no==6):
    print("day is friday")
else:
    print("day is saturday")
