l=[1,4,2,3,5]
print(l)
print(l.insert(0,"2"))

#remove
l.remove(4)
print(l)

#append
l.append(8)
print(l)

#length
len(l)
print(len(l))

#pop
l.pop(2)
print(l)

#clear
l.clear()
print(l)

#del
del()
print(l)

#concate
l1=["abc","xyz"]
l2=["efg","hij"]
l3=l1+l2
print(l3)

#slice operator

l4=[3,6,9,5]
l4[:]
print(l4)
print(l4[1:4])
print(l4[:4])
print(l4[:])

#nested list
l5=[3,5,[4,5,6,[3,4,5],7,8],4,5]
print(l5[2])
print(l5[2][1])

#repetation of list
l6=[1,2,3,4]
l7=[1,2,3,4,5]
l6=l7
print(l6)
print(l6 in [l7])
print(l5 not in [17])


#list itteration
s1=[1,2,3,4]
for i in s1:
    print(i)

#compare
s2=[a,b,c,d]
s3=[a,b,c,d]
if(s2==s3):
    print("list are equal")
else:
    print("list are not eual")

s1=s1.extend(s2)
print(s1)

p1=[1,2,3,4]
print(sum(p1))
print(len(p1))
print(s1.count(1))




